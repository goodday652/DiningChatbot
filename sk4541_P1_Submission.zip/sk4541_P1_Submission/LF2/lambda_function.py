import json
import os
import pprint

import boto3
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
from boto3.dynamodb.conditions import Key


REGION = 'us-east-1'
HOST = 'search-domain1-24xsg6b57jdid7qnech5btk7pm.us-east-1.es.amazonaws.com'
INDEX = 'restaurants' # ES index

# Give access to ElasticSearch & DynamoDb


def lambda_handler(event, context):
    
    print('event: ')
    print(event)
    
    
    #print(response)
    
    # dataChunkStr = event['Records'][0]['body']
    # print('dataChunkStr type: ')
    # print(type(dataChunkStr))
    
    # #converts str dataChunkStr -> dict dataChunkDict
    # dataChunkStrJsonForm = event.replace('\'','"')
    # dataChunkDict = json.loads(dataChunkStrJsonForm)

    data = event['Records'][0]['messageAttributes']

    # print('data: ')
    # print(data)
    # city = data['location']['stringValue']
    cuisine = data['cuisine']['stringValue']
    # num_people = data['num_people']['stringValue']
    # date = data['date']['stringValue']
    # time = data['time']['stringValue']
    # phone_num = data['phone_num']['stringValue']
    email = data['email']['stringValue']
    
    print('cuisine:')
    print(cuisine)
    # print('num_people: ')
    # print(num_people)
    # print('date: ')
    # print(date)
    # print('time: ')
    # print(time)
    # print('phone: ')
    # print(phone_num)

    
    # print('cuisine type: ')
    # print(type(cuisine))
    restaurantIDs = query(cuisine)
    print('restaurant IDs: ')
    print(restaurantIDs)
    msgToSend = restaurantsFromDynamoDB(restaurantIDs)
    
    #sns = boto3.client('sns')
    snsArn = 'arn:aws:sns:us-east-1:608785646063:RestaurantNotifier'
    

    # response = sns.publish( TopicArn = snsArn,
    #     Message = msgToSend,
    #     Subject='Restaurant Recommendation'
    # )
    sesArn = 'arn:aws:ses:us-east-1:608785646063:identity/sk4541@columbia.edu'
    
    ses = boto3.client('ses')
    
    destination = {
        'ToAddresses': [email], 'CcAddresses' : [], 'BccAddresses' : []
    }
    
    validMsgToSend = {
        'Subject': {'Data': 'subject1'},
        'Body': {'Text': 
                    {'Data': 
                        msgToSend}
        }
    }
    send_args = {
            'Source': 'sk4541@columbia.edu' ,
            'Destination': destination,
            'Message': validMsgToSend
    }
    response = ses.send_email(**send_args)
    print('Response from sending email: ')
    print(response)

    # return {
    #     'statusCode': 200,
    #     'headers': {
    #         'Content-Type': 'application/json',
    #         'Access-Control-Allow-Headers': 'Content-Type',
    #         'Access-Control-Allow-Origin': '*',
    #         'Access-Control-Allow-Methods': '*',
    #     },
    #     'body': json.dumps({'results': actualRestaurantInfo})
    # }

def restaurantsFromDynamoDB(retaurantIds):
    
    dynamodb = boto3.resource('dynamodb',region_name= "us-east-1")
    table = dynamodb.Table('Restaurants')
    
    restaurantsInfo = ''
    count = 0
    i = 1
    print(len(retaurantIds))
    for id in retaurantIds: # -> retaurantIds(:3)
        
        data = table.query(KeyConditionExpression=Key('id').eq(id)) # TODO: replace w/ id! sTu5z5HUcIYykg97HHj8xA
        print('Info retrieved from dynamoDb: ')
        print(data)
        if len(data['Items']) == 0:
            continue
        name = data['Items'][0]['name']
        # For some reason, the attribute is named 'address' in my dynamoDb even tho when i uploaded the data I saved it under 'location', thus I am using 'address'
        if 'location' not in data['Items'][0]:
            print('no location present')
            continue
        address = data['Items'][0]['location']['display_address']
        if 'review_count' not in data['Items'][0]:
            print('no review_count present')
            continue
        num_reviews = data['Items'][0]['review_count']
        if 'ratings' not in data['Items'][0]:
            print('no ratings present')
            continue
        rating = data['Items'][0]['ratings'] # TODO: change ratings -> rating
        if 'coordinates' not in data['Items'][0]:
            print('no coordinates present')
            continue
        coordinates = data['Items'][0]['coordinates']
        msg = "{}. Name: {}. Location: {}. Has {} reviews and a rating of {} on Yelp.\n \
                The coordinates are latutide: {} & longitude: {}".format(i, name, address, \
                num_reviews, rating, coordinates['latitude'], coordinates['longitude'])
        print('msg: ' + msg)
        restaurantsInfo = restaurantsInfo + msg + '\n'
        i = i + 1
        count = count + 1
        if count == 5:
            break
    print(restaurantsInfo)
    return restaurantsInfo

# Retrieves the restaurant ID via Elastic Search
# the parameter (term) to find the restaurants should be the desired *cuisine* rite?

def query(termToQuery):
    query = {'size': 50, 'query': {
            #                 "multi_match": {
            #                     "query": "chinese",
            #                     "fields": []
            #                 }
            #             }
            # }
        'match': {'cuisine': termToQuery}}}

    es = OpenSearch(hosts=[{
        'host': HOST,
        'port': 443
    }],
                        http_auth=get_awsauth(REGION, 'es'),
                        use_ssl=True,
                        verify_certs=True,
                        connection_class=RequestsHttpConnection)

    data = es.search(index=INDEX, body=query)

    print(data)

    hits = data['hits']['hits']
    print(hits)
    relevant_results = []
    for hit in hits:
        relevant_results.append(hit['_source'])
    print('query results: ')
    print(relevant_results)
    ids = []
    for result in relevant_results:
        id = result['id']
        ids.append(id)
    #print(ids)
    return ids


def get_awsauth(region, service):
    cred = boto3.Session().get_credentials()
    return AWS4Auth(cred.access_key,
                    cred.secret_key,
                    region,
                    service,
                    session_token=cred.token)
