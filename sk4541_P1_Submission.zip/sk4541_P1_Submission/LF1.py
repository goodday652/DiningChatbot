import json
import boto3
import math
import re
import datetime
import os
import time
import datetime

def pushRequestToSQS(cuisine, date, time, location, num_people, phone_num, email):
    sqs = boto3.client('sqs')  # don't need to specify access key rite?

    queue_url = "https://sqs.us-east-1.amazonaws.com/608785646063/LF1toLF2"
    print(location, cuisine, date, time, num_people, phone_num, email) 
    # Send message to SQS queue
    # supported 'DataType': string, number, binary
    response = sqs.send_message(
        QueueUrl=queue_url,
        MessageBody=(
            'DiningConcierge Bot user input'
        ),
        MessageAttributes={
            'location': {
                'StringValue': location,
                'DataType': 'String'
            },
            'cuisine': {
                'StringValue': cuisine,
                'DataType': 'String'
            },
            'date': {
                'StringValue': date,
                'DataType': 'String'
            },
            'time': {
                'StringValue': time,
                'DataType': 'String'
            },
            'num_people': {
                'StringValue': num_people,
                'DataType': 'Number'
            },
            'phone_num': {
                'StringValue': str(phone_num), 
                'DataType': 'Number'
            },
            'email': {
                'StringValue': email,
                'DataType': 'String'
            }
        }
    )
    print("SQS messageID:" + str(response['MessageId']))
    return

    
def sendCloseResponseToUser(session_attributes, fulfillment_state, message):
    return {
        'sessionState': {
            'sessionAttributes': session_attributes,
            'dialogAction': {
                'type': 'Close'
            }, 
            'intent':{
                    'state': fulfillment_state, # ?? not just 'Fulfilled bc may have failed rite?'
                    'name': 'DiningSuggestionsIntent'
            },
        },
        'messages': [{'contentType': 'PlainText', 
                    'content': message}]
    }
    return response


def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def build_validation_result(is_valid, violated_slot, message_content):
    if message_content is None:
        return {
            "isValid": is_valid,
            "violatedSlot": violated_slot
        }

    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': message_content
    }
    

def validate_dining(location, cuisine, time, date, num_people):
    
    locations = {'manhattan'}

    if location is not None:
        
        if location.lower() not in locations:
            return build_validation_result(False,
                                           'location',
                                           'Sorry, but we only support the location \'manhattan\'')
    
    cuisines = {'mexican', 'japanese', 'chinese', 'indian', 'italian'}
    if cuisine is not None:
        if cuisine.lower() not in cuisines:
            return build_validation_result(False,
                                       'cuisine',
                                       'Sorry, but we only support the following cuisines: chinese,'
                                       'japense, indian, mexican, italian. Please type in ones of those.')

    #TODO: make sure date is not in the past
    # TODO: make sure valid date (slot type accepts e.g. also mar 56)
    # ?? Okay that '3' gets interpreted to 03-01-2023? I'd think so...
    if date:
        print('date provided: ')
        print(date)
        today = datetime.datetime.now()
        print('today: ')
        print(today)
        if datetime.datetime.strptime(date, '%Y-%m-%d').date() < datetime.date.today():
             return build_validation_result(False, 'date', 'Please enter a date in the future, NOT the past!')
        
    if time is not None:
        print('time provided: ')
        print(time)
        if datetime.datetime.strptime(date, '%Y-%m-%d').date() == datetime.date.today():
            if datetime.datetime.strptime(time, '%H:%M').time() <= datetime.datetime.now().time():
                return build_validation_result(False, 'time',
                                           'Please enter a time in the future')
    if num_people is not None:
        num_people = int(num_people) # TODO: check for case 23.4 people
        if num_people <= 0 or num_people > 25:
            return build_validation_result(False, 'num_people',
                                           'Can only have between 1 and 25 people')
    

    return build_validation_result(True, None, None)

def elicit_slot(session_attributes, slot_to_elicit, message):
    
    return {
        'sessionState': {
            'sessionAttributes': session_attributes,
            'dialogAction': {
                'slotToElicit': slot_to_elicit,
                'type': 'ElicitSlot',
             
            }, 
            'intent':{
                #    'state': '__', # ?? What should this state be? get something sessionState
                    'name': 'DiningSuggestionsIntent'
            }
        },
        'messages': [{'contentType': 'PlainText', 
                    'content': message}]
    }


def delegate(session_attributes, slots):
    return {
        'sessionState': {
            'sessionAttributes': session_attributes,
            'dialogAction': {
            'type': 'Delegate',
            },
            'intent':{
                'state': 'ReadyForFulfillment',
                'name': 'DiningSuggestionsIntent',
                'slots': slots
            }

        }
        
    }

def returnNonInterpretableSlot(session_attributes, location, cuisine, date, time, num_people, phone_num, email):
    
    if location is not None:
        if 'interpretedValue' not in location['value']:
            return 'location'
    
    if cuisine is not None:
        if 'interpretedValue' not in cuisine['value']:
            return 'cuisine'
        
    if date is not None:
        if 'interpretedValue' not in date['value']:
            return 'date'
        
    if time is not None:
        if 'interpretedValue' not in time['value']:
            return 'time'
 
    if num_people is not None:
        if 'interpretedValue' not in num_people['value']:
            return 'num_people'

    if phone_num is not None:
        if 'interpretedValue' not in phone_num['value']:
            return 'phone_num'
            
    if email is not None:
        if 'interpretedValue' not in email['value']:
            return 'email'
    return None
        
        
def dining_suggestions(event):
    
    dining_intent = event['sessionState']['intent']
    #print(dining_intent)

    session_attributes = {}
    if event['sessionState']['sessionAttributes'] is not None:
        session_attributes = event['sessionState']['sessionAttributes']
        
    slots = dining_intent['slots']
    
    location = slots['location']
    cuisine = slots['cuisine']
    date = slots['date']
    time = slots['time']
    num_people = slots['num_people']
    phone_num = slots['phone_num']
    email = slots['email']
    
    '''If a value is not interpretable, return need to set that slot value to null so Lex can ask user for an (interpretable) value'''
    nonInterpretableSlot = returnNonInterpretableSlot(session_attributes, location, cuisine, date, time, num_people, phone_num, email)
    print('nonInterpretableSlot: ')
    print(nonInterpretableSlot)
    if nonInterpretableSlot is not None:
        # if nonInterpretableSlot == 'time':
        #     return elicit_slot(
        #         session_attributes,
        #         'time',
        #         'Please not only specify a # but also whether its \'am\' or \'pm\''
        #     )
        slots[nonInterpretableSlot] = None
        return delegate(session_attributes, slots)
    
    '''If reach here, there is an interpretable value'''
    if location is not None:
        location = location['value']['interpretedValue']
    if cuisine is not None:
        cuisine = cuisine['value']['interpretedValue']
    if date is not None:
        date = date['value']['interpretedValue']
    if time is not None:
        time = time['value']['interpretedValue']
    if num_people is not None:
        num_people = num_people['value']['interpretedValue']
    if phone_num is not None:
        phone_num = phone_num['value']['interpretedValue']
    if email is not None:
        email = email['value']['interpretedValue']

    if event['invocationSource'] == 'DialogCodeHook':
        # Check if slots are valid
    
        validation_result_assume_not_null = validate_dining(location, cuisine, time, date, num_people)  # only one violated slot will be returned at a time
        print("validation result: ")
        print(validation_result_assume_not_null)
        if not validation_result_assume_not_null['isValid']:
            print("elicit slots")
            # This is bc we want this slot to be requested again (since currently has a non-null value, but a faulty one)
            # if it was null to begin with, then itll become null again
            slots[validation_result_assume_not_null['violatedSlot']] = None

            return elicit_slot(
                session_attributes,
                validation_result_assume_not_null['violatedSlot'],
                validation_result_assume_not_null['message']
            )
        ''' delegate(...) tells Lex to determine the next action (As specified myself in the Lex console-- Conversation flow),
            as determined by the session_attributes and slots '''
        
        print('Reached here right before delegate(...)')
        return delegate(session_attributes, slots)
        

    elif event['invocationSource'] == 'FulfillmentCodeHook':

        pushRequestToSQS(cuisine, date, time, location, num_people, phone_num, email)
        print('pushed request to SQS')
        fulfillment_msg = "Thank you for the information. We will text you our recommendations soon."
        # fulfillment_state = event['interpretations']['intent']['state']
        # print('fulfillment state: ')
        # print(fulfillment_state) # ?? why this --> ReadyForFulfillment, when should be 'fulfilled'?
        return sendCloseResponseToUser(session_attributes,
                                       'Fulfilled', fulfillment_msg)


def greeting(event):
    session_attributes = {}
    if event['sessionState']['sessionAttributes'] is not None:
        session_attributes = event['sessionState']['sessionAttributes']

    return sendCloseResponseToUser(
        session_attributes, 'Fulfilled', 'Hello :)')


def thank_you(event):
    session_attributes = {}
    if event['sessionState']['sessionAttributes'] is not None:
        session_attributes = event['sessionState']['sessionAttributes']

    return sendCloseResponseToUser(
        session_attributes, 'Fulfilled', 'You are welcome, we hope to see you again!')


# intent: an action that the user wants to perform
# intent_request: a user's request to perform an intent (action)
def invoke_intent(event):
    print('Event: ')
    print(event)
    intent_name = event['sessionState']['intent']['name']
    print('Intent name: ' + str(intent_name))

    if intent_name == 'GreetingIntent':
        return greeting(event)
    elif intent_name == "DiningSuggestionsIntent":
        return dining_suggestions(event)
    elif intent_name == "ThankYouIntent":
        return thank_you(event)
    raise Exception('Intent ' + intent_name + ' not supported!')


def lambda_handler(event, context):
    # Set timezone to do time checks
    os.environ['TZ'] = 'America/New_York'
    time.tzset()
    print(event)
    return invoke_intent(event)

