import json
import time
from decimal import Decimal
import boto3
from botocore.exceptions import ClientError
import requests
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import pprint

## ?? Why needed to give permission from opensearch end, when just adding sth to it? (isn't it just 'one-way street', since only here -> opensearch?)
## ?? Sucessfully added index n filled it w/ contents? Why don't I see it in the domain1 then?

def getDataFromYelp():
    restaurantData = []
    cuisines = ['chinese', 'indian', 'japanese', 'mexican', 'italian', 'burger']
    for cuisine in cuisines:
        display_addresses = set()
        print("cuisine: " + cuisine)
        for i in range(50):
            requestData = {
                "term": cuisine + " restaurants",
                "location": 'Manhattan',
                "limit" : 20,
                "offset": 20 * i  # Fusion (Yelp API) returns max 20 each call
            }
            yelp_endpoint = "https://api.yelp.com/v3/businesses/search"

            headers = {
                "Authorization": "Bearer rjl4ZM6RmgAYqWvhpPty2h8zVWadtHgHyHE_OOcFjgLSWC0bmTrBdST4QwfzFvm-Cj-TehkdSDNLgy2CmJ8X_KJlWzRwvLJmweZEvGgUyDtOburO5Fav5tdGDfT8Y3Yx"
            }
            
            # while True:
            response = requests.get(yelp_endpoint, params=requestData, headers=headers)

            data = json.loads(response.text)
            
            # if 'businesses' not in data:
            #     continue
            #print(data)
            for business in data['businesses']:
                display_address_street = business['location']['display_address'][0]
                if display_address_street in display_addresses:
                    continue
                display_addresses.add(display_address_street)
                restaurant = {}
                if business == {}:
                    continue
                restaurant['id'] = business['id']
                restaurant['name'] = business['name']
                restaurant['cuisine'] = business['categories'][0]['title']
                restaurant['review_count'] = Decimal(business['review_count'])
                restaurant['ratings'] = Decimal(business['rating'])
                restaurant['location'] = business['location']
                coordinate_pair = business['coordinates'].items()
                restaurant['coordinates'] = {key: str(value) for key, value in coordinate_pair}
                restaurant['timeInserted'] = time.gmtime()
                restaurantData.append(restaurant)

        print(len(restaurantData))
    
    # with open("s3://my_bucket/my_file.csv", "w+") as f:
    #     w = csv.writer(f)
    #     w.writerows(filelist)
    
    # #upload the data into s3
    # bucket.upload_file("s3://my_bucket/my_file.csv", key)

    return restaurantData


def lambda_handler(event, context):
    # uni is the primary/paritition key
    # note they all have unique attributes

    # ?? We can determine ourselves which attributes are to be in the dynamoDb?
    restaurantData = getDataFromYelp()
    addElasticIndex(restaurantData)
    insert_data(restaurantData)

    return

def get_awsauth(region, service):
    cred = boto3.Session().get_credentials()
    return AWS4Auth(cred.access_key,
                    cred.secret_key,
                    region,
                    service,
                    session_token=cred.token)
                    

def addElasticIndex(restaurants):
    credentials = boto3.Session().get_credentials()
    region = "us-east-1"
    service = "es"
    awsauth = AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        region,
        service,
        session_token=credentials.token,
    )
    host = 'search-domain1-24xsg6b57jdid7qnech5btk7pm.us-east-1.es.amazonaws.com'
    es = OpenSearch(hosts=[{
        'host': host,
        'port': 443
    }],
        http_auth=get_awsauth('us-east-1', 'es'),
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection)
        
    for restaurant in restaurants:
        
        if restaurant == {}:
            continue
        index_data = {
            'id': restaurant['id'],
            'cuisine': restaurant['cuisine']
        }
        #print('dataObject', index_data)

        es.index(index="restaurants", id=restaurant['id'], body=index_data, refresh=True)

def insert_data(data_list, db=None, table='Restaurants'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # overwrite if the same index is provided
    for data in data_list:
        #print(data)
        response = table.put_item(Item=data)
    #print('@insert_data: response', response)
    return response # ?? Why returing only last response?


def lookup_data(key, db=None, table='Restaurants'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        print(response['Item'])
        return response['Item']


def update_item(key, feature, db=None, table='Restaurants'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # change student location
    response = table.update_item(
        Key=key,
        UpdateExpression="set #feature=:f",
        ExpressionAttributeValues={
            ':f': feature
        },
        ExpressionAttributeNames={
            "#feature": "from"
        },
        ReturnValues="UPDATED_NEW"
    )
    #print(response)
    return response


