import boto3 # AWS SDK for python
import json # to make dicitonary more readable
import pprint

# Define the client to interact with Lex
client = boto3.client('lexv2-runtime')

def lambda_handler(event, context):
    print('event: ')
    print(event)
    # bodyStr = event['body']
    # print('str: ')
    # print(bodyStr)
    # print('type: ')
    # print(type(bodyStr))
    # bodyStr = bodyStr.replace('\'','')
    # bodyJson = json.loads(bodyStr)
    
    
    
    msg_from_user = event['messages'][0]['unstructured']['text'] # How know urself what the keys of event are? - A: depends on what the client sends--
                    # In our case, check what the API gateway sends back, which is clear by the OpenAPI swagger editor
                    
    print(f"Message from frontend: {msg_from_user}") 

    # Initiate conversation with Lex
    # Hooking to Lex thru the botId, botAliasId (so for now no need to hook via the Lex Console)
    response = client.recognize_text( botId='NSMWFP06CV', # MODIFY HERE
            botAliasId='E5QICHF2YV', # MODIFY HERE
            localeId='en_US',
            sessionId='testuser',
            text=msg_from_user)
            

    pprint.pprint(response)
    #print(response['messages'][0]['content']) # We r printing this so we know what we r sending to the user
    msg_from_lex = response.get('messages', []) # if no key 'message' found then it returns []
    
    if msg_from_lex: # if response not null
      # print('Message was not null')
        msg_from_chatbot = ''
        for msg in msg_from_lex:
            msg_from_chatbot = msg_from_chatbot + msg['content'] + '.'
        print(f"Message from Chatbot: {msg_from_chatbot}")
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': ''
            },
            #'body': {
                "messages": [
                    {
                    "type": "unstructured",
                    "unstructured": {
                        "id": "string",
                        "text": msg_from_chatbot,
                        "timestamp": "string"
                        }
                    }
                ]
            # }
        }

