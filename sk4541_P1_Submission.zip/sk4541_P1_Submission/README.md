# DiningChatbot

Name: Sarah Kim
Uni: sk4541
S3 frontend URL: https://s3.amazonaws.com/diningchatbotskdg.com/chat.html

Note: addElasticSearchAndDynamoDbData includes the Yelp Scraper Script (I got the data from Yelp, made the Elastic Search Index, and uploaded the data to dynamo db all in one script)
